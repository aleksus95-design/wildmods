﻿param([string]$PaksDirectory = 'D:\SteamLibrary\steamapps\common\SCUM\SCUM\Content\Paks')
$ErrorActionPreference = 'Stop'
if (Get-Process -Name 'SCUM','SCUM-Win64-Shipping' -ErrorAction SilentlyContinue) { throw 'Закройте клиент SCUM перед установкой.' }
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'evidence/manifest.json') -Raw | ConvertFrom-Json
$sourcePak = Join-Path $PSScriptRoot $manifest.name
if ((Get-FileHash -LiteralPath $sourcePak -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.sha256) { throw 'SHA-256 исходного PAK не совпал.' }
$resolvedPaks = (Resolve-Path -LiteralPath $PaksDirectory).Path
if ((Split-Path -Leaf $resolvedPaks) -ne 'Paks' -or (Split-Path -Leaf (Split-Path -Parent $resolvedPaks)) -ne 'Content') { throw 'Укажите папку SCUM/Content/Paks.' }
$modsFolder = Join-Path $resolvedPaks '~mods'
New-Item -ItemType Directory -Path $modsFolder -Force | Out-Null
$targetPak = Join-Path $modsFolder $manifest.name
if (Test-Path -LiteralPath $targetPak) {
    if ((Get-FileHash -LiteralPath $targetPak -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.sha256) { throw 'Под этим именем уже существует другой файл; установка остановлена.' }
} else { Copy-Item -LiteralPath $sourcePak -Destination $targetPak }
if ((Get-FileHash -LiteralPath $targetPak -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.sha256) { throw 'SHA-256 после копирования не совпал.' }
Write-Output 'Silver R7 установлен. Прежние PAK сохранены. Применится при следующем запуске клиента.'
